import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  angForm: FormGroup;
  loginForm: FormGroup
  displayBasic = false;
  @Output() cusDetails = new EventEmitter<String>();
  @Output() logintoHome = new EventEmitter<String>();

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.createForm();


  }

  ngOnInit(): void {
    this.loginform();
  }
  createForm() {
    this.angForm = this.fb.group({
      name: ['', Validators.required],
      address: ['', Validators.required],
      phone: ['', Validators.required],
      password: ['', Validators.required],
      email: ['', Validators.required],
    });
  }
loginform() {
  this.loginForm = this.fb.group({
    lname: new FormControl(),
    lpwd: new FormControl(),
  });
}

cusdetails() {
  this.cusDetails.emit();
}
homepage() {
  this.logintoHome.emit();
  console.log(this.loginForm.value)
}
onsubmit() {
  console.log(this.loginForm.value)
}

}
